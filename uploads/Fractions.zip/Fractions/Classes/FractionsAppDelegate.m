//
//  FractionsAppDelegate.m
//  Fractions
//
//  Created by UUC on 06/04/2009.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "FractionsAppDelegate.h"
#import "MyViewController.h"

@implementation FractionsAppDelegate

@synthesize myViewController;
@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    MyViewController *aViewController = [[MyViewController alloc] initWithNibName:@"ControllerView" bundle:[NSBundle mainBundle]];
	self.myViewController = aViewController;
	[aViewController release];
	
	UIView *controllersView = [myViewController view];
	[window addSubview: controllersView];
    [window makeKeyAndVisible];
}


- (void)dealloc {
	[myViewController release];
    [window release];
    [super dealloc];
}


@end
