//
//  MyViewController.m
//  Fractions
//
//  Created by UUC on 07/04/2009.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MyViewController.h"
#import "Fraction.h"

@implementation MyViewController

@synthesize numTextField;
@synthesize denTextField;
@synthesize fractionLabel;
@synthesize decimalLabel;
@synthesize percentageLabel;
@synthesize fraction;

- (IBAction)changeResult:(id)sender
{
	if([numTextField.text length] == 0 || [denTextField.text length] == 0)
	{
		fractionLabel.text = @"What?";
		decimalLabel.text = @"Huh?";
		percentageLabel.text = @":-|";
	}// if
	else
	{
		fraction = [Fraction alloc];
		fraction.numerator = numTextField.text;
		fraction.denominator = denTextField.text;
		
		fractionLabel.text = [fraction combineFraction];
		decimalLabel.text = [fraction calculateDecimal];
		percentageLabel.text = [fraction calculatePercentage];
	}// else
}// changeResult

- (BOOL)textFieldShouldReturn:(UITextField *)theTextField
{
	if(theTextField == numTextField)
		[numTextField resignFirstResponder];
	else if(theTextField == denTextField)
		[denTextField resignFirstResponder];
	
	return YES;
}// textFieldShouldReturn

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[numTextField release];
	[denTextField release];
	[fractionLabel release];
	[decimalLabel release];
	[percentageLabel release];
	[fraction dealloc];
    [super dealloc];
}


@end
