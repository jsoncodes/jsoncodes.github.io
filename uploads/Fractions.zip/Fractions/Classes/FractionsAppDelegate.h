//
//  FractionsAppDelegate.h
//  Fractions
//
//  Created by UUC on 06/04/2009.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyViewController;

@interface FractionsAppDelegate : NSObject <UIApplicationDelegate> {
	@private
    UIWindow *window;
	MyViewController *myViewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) MyViewController *myViewController;

@end

