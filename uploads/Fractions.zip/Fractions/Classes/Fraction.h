//
//  Fraction.h
//  Fractions
//
//  Created by UUC on 06/04/2009.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Fraction : NSObject {
	@private
	NSString *numerator;
	NSString *denominator;
}

- (void) dealloc;
- (NSString*) combineFraction;
- (NSString*) calculateDecimal;
- (NSString*) calculatePercentage;

@property (nonatomic, retain) NSString *numerator;
@property (nonatomic, retain) NSString *denominator;

@end
