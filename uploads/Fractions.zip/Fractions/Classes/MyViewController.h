//
//  MyViewController.h
//  Fractions
//
//  Created by UUC on 07/04/2009.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Fraction;

@interface MyViewController : UIViewController <UITextFieldDelegate> 
{
	@private
	UITextField *numTextField;
	UITextField *denTextField;
	UILabel *fractionLabel;
	UILabel *decimalLabel;
	UILabel *percentageLabel;
	Fraction *fraction;
}

- (IBAction)changeResult:(id)sender;

@property (nonatomic, retain) IBOutlet UITextField *numTextField;
@property (nonatomic, retain) IBOutlet UITextField *denTextField;
@property (nonatomic, retain) IBOutlet UILabel *fractionLabel;
@property (nonatomic, retain) IBOutlet UILabel *decimalLabel;
@property (nonatomic, retain) IBOutlet UILabel *percentageLabel;
@property (nonatomic, copy) Fraction *fraction;

@end
