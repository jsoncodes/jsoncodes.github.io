//
//  Fraction.m
//  Fractions
//
//  Created by UUC on 06/04/2009.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Fraction.h"


@implementation Fraction

@synthesize numerator;
@synthesize denominator;

- (void) dealloc
{
	[numerator release];
	[denominator release];
	[super dealloc];
}// dealloc

- (NSString*) combineFraction
{
	NSString *string = [[[NSString alloc] initWithFormat:@"%@ / %@",numerator,denominator] autorelease];
	return string;
}// combineFraction

- (NSString*) calculateDecimal
{
	NSDecimalNumber *num = [NSDecimalNumber decimalNumberWithString:numerator];
	NSDecimalNumber *den = [NSDecimalNumber decimalNumberWithString:denominator];
	num = [num decimalNumberByDividingBy:den];

	NSString *string = [[[NSString alloc] initWithFormat:@"%@",[num stringValue]] autorelease];
	
	return string;
}// calculateDecimal

- (NSString*) calculatePercentage
{
	NSDecimalNumber *num = [NSDecimalNumber decimalNumberWithString:[self calculateDecimal]];
	NSDecimalNumber *times = [NSDecimalNumber decimalNumberWithString:@"100"];
	num = [num decimalNumberByMultiplyingBy:times];
	
	NSString *string = [[[NSString alloc] initWithFormat:@"%@",[num stringValue]] autorelease];
	
	return string;
}// calculatePercentage

@end
