﻿using System;
using System.Collections.Generic;

namespace WindowsGame2
{
    public class Observable<T>
    {
        private readonly List<Action<T>> subscriptions = new List<Action<T>>();
        private T observableValue;

        public Action<T> Subscribe(Action<T> callback)
        {
            subscriptions.Add(callback);
            return callback;
        }

        public void Unsubscribe(Action<T> callback)
        {
            subscriptions.Remove(callback);
        }

        public void UnsubscribeAll()
        {
            subscriptions.Clear();
        }

        private void NotifyValueChanged()
        {
            foreach (Action<T> callback in subscriptions)
                callback(observableValue);
        }

        public T Value
        {
            get { return observableValue; }
            set
            {
                observableValue = value;
                NotifyValueChanged();
            }
        }
    }
}
