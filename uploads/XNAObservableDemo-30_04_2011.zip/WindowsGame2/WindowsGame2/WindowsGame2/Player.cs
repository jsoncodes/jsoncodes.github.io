﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace WindowsGame2
{
    public class Player
    {
        private readonly Observable<Vector2> position = new Observable<Vector2>();

        public void Update(GameTime gameTime)
        {
            MouseState mouse = Mouse.GetState();
            position.Value = new Vector2(mouse.X, mouse.Y);
        }

        public Observable<Vector2> Position
        {
            get { return position; }
        }
    }
}
