﻿using System.Windows.Controls;
using BingMaps.MapServiceReference;
using Microsoft.Maps.MapControl;

namespace BingMaps
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void MapControl_MouseClick(object sender, MapMouseEventArgs e)
        {
            if (PlacePinRadio.IsChecked == true)
                PlacePinOnMap(e);
            else if (GetLocationRadio.IsChecked == true)
                GetCountryFromClickLocation(e);
        }

        private void GetCountryFromClickLocation(MapMouseEventArgs mapMouseEventArgs)
        {
            Location worldCoords = MapControl.ViewportPointToLocation(mapMouseEventArgs.ViewportPoint);

            GeocodeServiceClient geocodeClient = new GeocodeServiceClient("BasicHttpBinding_IGeocodeService");
            geocodeClient.ReverseGeocodeCompleted += ReverseGeocodeCompleted;

            ReverseGeocodeRequest request = new ReverseGeocodeRequest();
            request.Culture = MapControl.Culture;
            request.Location = worldCoords;
            request.ExecutionOptions = new ExecutionOptions();
            request.ExecutionOptions.SuppressFaults = true;

            MapControl.CredentialsProvider.GetCredentials(credentials =>
                                                                {
                                                                    request.Credentials = credentials;
                                                                    geocodeClient.ReverseGeocodeAsync(request);
                                                                });
        }

        private void ReverseGeocodeCompleted(object sender, ReverseGeocodeCompletedEventArgs e)
        {
            ResultTextBlock.Text = "Country: " + e.Result.Results[0].Address.CountryRegion;
        }

        private void PlacePinOnMap(MapMouseEventArgs mapMouseEventArgs)
        {
            Location worldCoords = MapControl.ViewportPointToLocation(mapMouseEventArgs.ViewportPoint);
            Pushpin pushpin = new Pushpin {Location = worldCoords};

            MapControl.Children.Add(pushpin);
        }
    }
}
