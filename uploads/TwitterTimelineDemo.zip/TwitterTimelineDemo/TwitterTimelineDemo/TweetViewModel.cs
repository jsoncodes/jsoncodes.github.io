﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Xml.Linq;

namespace TwitterTimelineDemo
{
    public class TweetViewModel
    {
        private readonly ObservableCollection<Tweet> tweets = new ObservableCollection<Tweet>();

        public TweetViewModel()
        {
            WebClient webClient = new WebClient();
            webClient.DownloadStringCompleted += new DownloadStringCompletedEventHandler(DownloadStringCompleted);
            webClient.DownloadStringAsync(new Uri("http://search.twitter.com/search.atom?q=from%3Ajmitch18", UriKind.Absolute));
        }

        private void DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            foreach (Tweet tweet in GetTwitterEntries(e.Result))
                tweets.Add(tweet);
        }

        private IEnumerable<Tweet> GetTwitterEntries(string twitterFeed)
        {
            XNamespace atomNS = "http://www.w3.org/2005/Atom";
            XDocument feed = XDocument.Parse(twitterFeed);

            IEnumerable<Tweet> entries = from tweet in feed.Descendants(atomNS + "entry")
                                         select new Tweet
                                         {
                                             Status = (string)tweet.Element(atomNS + "title"),
                                             Date = DateTime.Parse((string)tweet.Element(atomNS + "published"))
                                         };

            return entries;
        }

        public ObservableCollection<Tweet> Tweets
        {
            get { return tweets; }
        }
    }
}
