﻿using System;

namespace TwitterTimelineDemo
{
    public class Tweet
    {
        public string Status { get; set; }
        public DateTime Date { get; set; }
    }
}
