using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Particles.Particles;
using Particles.Particles.Modifiers;

namespace Particles
{
    public class Game1 : Game
    {
        private AttachedCamera camera;
        private ParticleEffect particleEffect;

        public Game1()
        {
            new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            particleEffect = new ParticleEffect(2000, 7500, 2, 2f, Blend.One);
            particleEffect.Modifiers.Add(new AlphaAgeModifier());

            camera = new AttachedCamera(Vector3.Zero, new Vector3(0, 1000, 1000), MathHelper.PiOver4, GraphicsDevice.Viewport.AspectRatio, 1, 50000);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            List<Texture2D> textures = new List<Texture2D> {Content.Load<Texture2D>("Particles/fire")};
            particleEffect.LoadContent(textures, GraphicsDevice);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                Exit();

            particleEffect.Emit(gameTime, Vector3.Zero);
            particleEffect.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {           
            GraphicsDevice.Clear(Color.Black);

            particleEffect.Draw(GraphicsDevice, camera.ViewMatrix, camera.ProjectionMatrix);

            base.Draw(gameTime);
        }
    }
}
