﻿namespace Particles.Particles.Modifiers
{
    public abstract class Modifier
    {
        public abstract void Update(Particle particle, float particleAge);
    }
}
