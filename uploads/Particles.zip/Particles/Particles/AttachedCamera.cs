﻿using Microsoft.Xna.Framework;

namespace Particles
{
    public class AttachedCamera
    {
        private readonly Vector3 offset;

        public AttachedCamera(Vector3 attachPosition, Vector3 cameraOffset, float fieldOfView, float aspectRatio, float nearPlaneDistance, float farPlaneDistance)
        {
            offset = cameraOffset;

            ProjectionMatrix = Matrix.CreatePerspectiveFieldOfView(fieldOfView, aspectRatio, nearPlaneDistance, farPlaneDistance);
            ViewMatrix = Matrix.CreateLookAt(attachPosition + offset, attachPosition, Vector3.Up);
        }

        public void Update(Vector3 attachPosition)
        {
            // Calculate camera lag
            ViewMatrix = Matrix.CreateLookAt(attachPosition + offset, attachPosition, Vector3.Up);
        }

        public Matrix ProjectionMatrix { get; private set; }
        public Matrix ViewMatrix { get; private set; }
    }
}
