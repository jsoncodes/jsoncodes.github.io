using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MatrixTransformCamera
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        private readonly Camera camera;
        private Texture2D texture;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            camera = new Camera();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            texture = Content.Load<Texture2D>("image");
        }

        protected override void Update(GameTime gameTime)
        {
            KeyboardState keyState = Keyboard.GetState();
            TranslateCamera(keyState);
            RotateCamera(keyState);
            ZoomCamera(keyState);

            base.Update(gameTime);
        }

        private void ZoomCamera(KeyboardState keyState)
        {
            float scale = 0f;
            if (keyState.IsKeyDown(Keys.W))
                scale += 0.05f;
            if (keyState.IsKeyDown(Keys.S))
                scale -= 0.05f;

            camera.Zoom += scale;
        }

        private void RotateCamera(KeyboardState keyState)
        {
            float rotation = 0f;
            if (keyState.IsKeyDown(Keys.A))
                rotation -= 5;
            if (keyState.IsKeyDown(Keys.D))
                rotation += 5;

            camera.Rotation += MathHelper.ToRadians(rotation);
        }

        private void TranslateCamera(KeyboardState keyState)
        {
            Vector2 cameraTranslate = Vector2.Zero;
            if (keyState.IsKeyDown(Keys.Up))
                cameraTranslate.Y -= 5;
            if (keyState.IsKeyDown(Keys.Down))
                cameraTranslate.Y += 5;
            if (keyState.IsKeyDown(Keys.Left))
                cameraTranslate.X -= 5;
            if (keyState.IsKeyDown(Keys.Right))
                cameraTranslate.X += 5;

            camera.Position += cameraTranslate;
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Texture, SaveStateMode.None, camera.TransformMatrix);
            spriteBatch.Draw(texture, Vector2.Zero, Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
