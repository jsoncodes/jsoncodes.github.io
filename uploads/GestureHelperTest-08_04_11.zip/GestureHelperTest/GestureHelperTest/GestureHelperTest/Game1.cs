using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input.Touch;

namespace GestureHelperTest
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        private Texture2D square;
        private Vector2 position;
        private Vector2 origin;
        private float scale = 1;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this)
                           {
                               IsFullScreen = true,
                               SupportedOrientations = DisplayOrientation.Portrait,
                               PreferredBackBufferHeight = 800,
                               PreferredBackBufferWidth = 480
                           };

            Content.RootDirectory = "Content";
            TargetElapsedTime = TimeSpan.FromTicks(333333);
        }

        protected override void Initialize()
        {
            GestureHelper.Initialize(this);
            GestureHelper.Instance.AddCallback(GestureType.FreeDrag, gestureSample => position = gestureSample.Position);
            GestureHelper.Instance.AddCallback(GestureType.Hold, gestureSample => scale = 1);
            GestureHelper.Instance.AddCallback(GestureType.Tap, ScaleSquare);

            base.Initialize();
        }

        private void ScaleSquare(GestureSample gestureSample)
        {
            scale += 0.1f;
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            square = Content.Load<Texture2D>("Square");
            origin = new Vector2(square.Width / 2, square.Height / 2);

            position = origin;
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            spriteBatch.Begin();
            spriteBatch.Draw(square, position, null, Color.White, 0, origin, scale, SpriteEffects.None, 0f);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
