using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input.Touch;

namespace GestureHelperTest
{
    public class GestureHelper : GameComponent
    {
        public static GestureHelper Instance { get; private set; }

        public static void Initialize(Game game)
        {
            if (Instance != null)
                throw new InvalidOperationException("Only one instance of GestureHelper can be created.");

            Instance = new GestureHelper(game);
            game.Components.Add(Instance);
        }

        private readonly Dictionary<GestureType, List<Action<GestureSample>>> gestureCallbacks;

        private GestureHelper(Game game) : base(game)
        {
            TouchPanel.EnabledGestures = GestureType.None;
            gestureCallbacks = new Dictionary<GestureType, List<Action<GestureSample>>>();
        }

        public void AddCallback(GestureType gestureType, Action<GestureSample> callback)
        {
            if (!gestureCallbacks.ContainsKey(gestureType))
            {
                TouchPanel.EnabledGestures |= gestureType;
                gestureCallbacks.Add(gestureType, new List<Action<GestureSample>>());
            }

            gestureCallbacks[gestureType].Add(callback);
        }

        public void Clear()
        {
            TouchPanel.EnabledGestures = GestureType.None;
            gestureCallbacks.Clear();
        }

        public void ClearGesture(GestureType gestureType)
        {
            TouchPanel.EnabledGestures -= gestureType;
            gestureCallbacks.Remove(gestureType);
        }

        public override void Update(GameTime gameTime)
        {
            while (TouchPanel.IsGestureAvailable)
            {
                GestureSample gestureSample = TouchPanel.ReadGesture();

                if (gestureCallbacks.ContainsKey(gestureSample.GestureType))
                {
                    foreach (Action<GestureSample> callback in gestureCallbacks[gestureSample.GestureType])
                        callback(gestureSample);
                }
            }

            base.Update(gameTime);
        }
    }
}
