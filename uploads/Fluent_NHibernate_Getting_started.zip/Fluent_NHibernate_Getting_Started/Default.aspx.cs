﻿using System;
using System.Linq;
using NHibernate;
using NHibernate.Linq;
using WebApplication1.Entities;

namespace WebApplication1
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ISession session = (ISession) Context.Items["NHSession"];
            CreateUsers(session);

            var users = from u in session.Query<User>()
                        select u;

            grdUsers.DataSource = users;
            grdUsers.DataBind();
        }

        private void CreateUsers(ISession session)
        {
            if(session.Query<User>().Count() < 3)
            {
                using(ITransaction transaction = session.BeginTransaction())
                {
                    for (int i = 1; i <= 3; i++)
                    {
                        User user = new User { EmailAddress = string.Format("user{0}@test.com", i), Password = "password" };
                        session.Save(user);
                    }

                    transaction.Commit();
                }
            }
        }
    }
}