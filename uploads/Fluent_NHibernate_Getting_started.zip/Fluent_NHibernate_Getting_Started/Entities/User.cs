﻿namespace WebApplication1.Entities
{
    public class User
    {
        public virtual int ID { get; set; }
        public virtual string EmailAddress { get; set; }
        public virtual string Password { get; set; }
    }
}