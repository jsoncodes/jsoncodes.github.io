﻿using System;
using FluentNHibernate.Automapping;

namespace WebApplication1
{
    public class AutomappingConfiguration : DefaultAutomappingConfiguration
    {
        public override bool ShouldMap(Type type)
        {
            return type.Namespace == "WebApplication1.Entities";
        }
    }
}