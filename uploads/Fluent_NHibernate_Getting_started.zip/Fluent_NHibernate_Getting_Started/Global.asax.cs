﻿using System;
using System.Configuration;
using FluentNHibernate.Automapping;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using WebApplication1.Entities;

namespace WebApplication1
{
public class Global : System.Web.HttpApplication
{
    protected void Application_Start(object sender, EventArgs e)
    {
        Application["NHSessionFactory"] = CreateSessionFactory();
    }

    private static ISessionFactory CreateSessionFactory()
    {
        return Fluently.Configure()
            .Database(MsSqlConfiguration.MsSql2008
                .ConnectionString(ConfigurationManager.AppSettings["ConnectionString"]))
            .Mappings(m => m.AutoMappings.Add(CreateAutomappings))
            .BuildSessionFactory();
    }

    private static AutoPersistenceModel CreateAutomappings()
    {
        return AutoMap
            .AssemblyOf<AutomappingConfiguration>(new AutomappingConfiguration())
            .Override<User>(u => u.Table("tUser"));
    }

    protected void Application_BeginRequest(object sender, EventArgs e)
    {
        ISessionFactory sessionFactory = (ISessionFactory) Application["NHSessionFactory"];
        Context.Items["NHSession"] = sessionFactory.OpenSession();
    }

    protected void Application_EndRequest(object sender, EventArgs e)
    {
        ISession session = (ISession) Context.Items["NHSession"];
        session.Dispose();
    }

    protected void Application_End(object sender, EventArgs e)
    {
        ISessionFactory sessionFactory = (ISessionFactory)Application["NHSessionFactory"];
        sessionFactory.Dispose();
    }
}
}