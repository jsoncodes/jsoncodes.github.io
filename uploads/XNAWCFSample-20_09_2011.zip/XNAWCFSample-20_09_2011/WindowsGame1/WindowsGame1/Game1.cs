using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using WindowsGame1.ServiceReference1;

namespace WindowsGame1
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private SpriteFont spriteFont;

        private TestServiceClient testServiceClient;
        private string databaseMessage;
        private string statusMessage;

        private MouseState prevState = Mouse.GetState();
        
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // client to access the web service through
            testServiceClient = new TestServiceClient();

            // call the GetMessageFromDatabase method on service
            databaseMessage = testServiceClient.GetMessageFromDatabase();

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteFont = Content.Load<SpriteFont>("SpriteFont1");
        }

        protected override void Update(GameTime gameTime)
        {
            MouseState state = Mouse.GetState();

            if(state.LeftButton == ButtonState.Pressed && prevState.LeftButton == ButtonState.Released)
            {
                statusMessage = string.Format("Click at {0}, {1} sent to database.", state.X, state.Y);

                // Send click to database
                testServiceClient.SendClickAsync(DateTime.Now, state.X, state.Y);
            }

            prevState = state;

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            spriteBatch.DrawString(spriteFont, databaseMessage, new Vector2(50), Color.White);

            if (!string.IsNullOrEmpty(statusMessage))
            {
                spriteBatch.DrawString(spriteFont, statusMessage, new Vector2(50, 100), Color.White);
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
