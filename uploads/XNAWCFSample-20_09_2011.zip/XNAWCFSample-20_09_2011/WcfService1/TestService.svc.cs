﻿using System;
using System.Linq;

namespace WcfService1
{
    public class TestService : ITestService
    {
        public string GetMessageFromDatabase()
        {
            // Create LINQ to SQL context to access database
            using(ServiceDataContext context = new ServiceDataContext())
            {
                // Get record from Message table with an ID = 1
                return context.Messages.Single(m => m.Id == 1).MessageText;
            }
        }

        public void SendClick(DateTime dateTime, float positionX, float positionY)
        {
            // Create a new instance of the auto-generated LINQ to SQL class for click table
            Click newClick = new Click
            {
                Time = dateTime,
                PositionX = positionX,
                PositionY = positionY
            };

            // Create LINQ to SQL context to access database
            using(ServiceDataContext context = new ServiceDataContext())
            {
                // Add new click to the Click table
                context.Clicks.InsertOnSubmit(newClick);

                // Commit the changes to the database
                context.SubmitChanges();
            }
        }
    }
}
