﻿using System;
using System.ServiceModel;

namespace WcfService1
{
    [ServiceContract]
    public interface ITestService
    {
        [OperationContract]
        string GetMessageFromDatabase();

        [OperationContract]
        void SendClick(DateTime dateTime, float positionX, float positionY);
    }
}
