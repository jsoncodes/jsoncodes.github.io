﻿using System;
using System.ServiceModel;
using ConsoleApplication1.ServiceReference1;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            InstanceContext context = new InstanceContext(new CallbackType());
            ServiceWithCallbackClient client = new ServiceWithCallbackClient(context);
            client.StartDataOutput();

            Console.ReadLine();
        }
    }
}
