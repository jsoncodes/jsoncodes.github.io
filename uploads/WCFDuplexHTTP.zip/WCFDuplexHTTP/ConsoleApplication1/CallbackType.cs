﻿using System;

namespace ConsoleApplication1
{
    class CallbackType : ServiceReference1.IServiceWithCallbackCallback
    {
        public void SendMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
