﻿using System.ServiceModel;

namespace Framework.Networking.Services.Callbacks
{
    public interface IDataOutputCallback
    {
        [OperationContract(IsOneWay = true)]
        void SendMessage(string message);
    }
}
