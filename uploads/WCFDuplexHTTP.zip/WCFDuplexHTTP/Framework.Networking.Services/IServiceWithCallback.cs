﻿using System.ServiceModel;
using Framework.Networking.Services.Callbacks;

namespace Framework.Networking.Services
{
    [ServiceContract(Namespace = "Framework.Networking.Services", CallbackContract = typeof(IDataOutputCallback))]
    public interface IServiceWithCallback
    {
        [OperationContract(IsOneWay = true)]
        void StartDataOutput();
    }
}
