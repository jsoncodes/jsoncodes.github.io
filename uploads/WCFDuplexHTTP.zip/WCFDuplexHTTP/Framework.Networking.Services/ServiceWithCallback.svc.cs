﻿using System.ServiceModel;
using System.Threading;
using Framework.Networking.Services.Callbacks;

namespace Framework.Networking.Services
{
    public class ServiceWithCallback : IServiceWithCallback
    {
        public void StartDataOutput()
        {
            IDataOutputCallback callback = OperationContext.Current.GetCallbackChannel<IDataOutputCallback>();
            callback.SendMessage("Start");

            for(int i = 0; i < 10; i++)
            {
                Thread.Sleep(250);
                callback.SendMessage(i.ToString());
            }

            callback.SendMessage("End");
        }
    }
}
