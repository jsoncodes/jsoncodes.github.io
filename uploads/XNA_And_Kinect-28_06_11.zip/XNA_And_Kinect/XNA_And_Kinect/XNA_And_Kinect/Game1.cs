using System;
using System.Collections.Generic;
using Microsoft.Research.Kinect.Nui;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace XNA_And_Kinect
{
    public class Game1 : Game
    {
        private const int EdgeOffset = 10;
        private const int HotSpotSizes = 100;
        private const float HotSpotAlpha = 0.5f;
        private const int JointIntersectionSize = 80;

        private readonly GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;

        private Runtime kinectRuntime;

        private readonly TextureInstance kinectRGBVideo = new TextureInstance();
        private readonly List<TextureInstance> hotSpots = new List<TextureInstance>();

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = 640;
            graphics.PreferredBackBufferHeight = 480;

            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            kinectRuntime = new Runtime();
            kinectRuntime.Initialize(RuntimeOptions.UseColor | RuntimeOptions.UseSkeletalTracking);
            kinectRuntime.VideoStream.Open(ImageStreamType.Video, 2, ImageResolution.Resolution640x480, ImageType.Color);

            kinectRuntime.VideoFrameReady += VideoFrameReady;
            kinectRuntime.SkeletonFrameReady += SkeletonFrameReady;

            base.Initialize();
        }

        protected override void OnExiting(object sender, EventArgs args)
        {
            kinectRuntime.Uninitialize();
            base.OnExiting(sender, args);
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            kinectRGBVideo.Texture = new Texture2D(GraphicsDevice, 640, 480, false, SurfaceFormat.Color);

            TextureInstance texture = TextureInstance.CreateBlank(GraphicsDevice, HotSpotSizes, HotSpotSizes);
            texture.Position = new Vector2(EdgeOffset);
            texture.Alpha = HotSpotAlpha;
            hotSpots.Add(texture);

            texture = TextureInstance.CreateBlank(GraphicsDevice, HotSpotSizes, HotSpotSizes);
            texture.Position = new Vector2(GraphicsDevice.Viewport.Width - texture.Texture.Width - EdgeOffset, EdgeOffset);
            texture.Alpha = HotSpotAlpha;
            hotSpots.Add(texture);

            texture = TextureInstance.CreateBlank(GraphicsDevice, HotSpotSizes, HotSpotSizes);
            texture.Position = new Vector2(10, GraphicsDevice.Viewport.Height - texture.Texture.Height - EdgeOffset);
            texture.Alpha = HotSpotAlpha;
            hotSpots.Add(texture);

            texture = TextureInstance.CreateBlank(GraphicsDevice, HotSpotSizes, HotSpotSizes);
            texture.Position = new Vector2(GraphicsDevice.Viewport.Width - texture.Texture.Width - EdgeOffset, GraphicsDevice.Viewport.Height - texture.Texture.Height - EdgeOffset);
            texture.Alpha = HotSpotAlpha;
            hotSpots.Add(texture);

            ResetSquareColors();
        }

        private void ResetSquareColors()
        {
            foreach (TextureInstance texture in hotSpots)
                texture.Color = Color.Red;
        }

        private void VideoFrameReady(object sender, ImageFrameReadyEventArgs e)
        {
            PlanarImage image = e.ImageFrame.Image;
            kinectRGBVideo.Texture = image.ToTexture2D(GraphicsDevice);
        }

        private void SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            SkeletonFrame skeletonFrame = e.SkeletonFrame;
            ResetSquareColors();

            foreach (SkeletonData data in skeletonFrame.Skeletons)
            {
                if (data.TrackingState == SkeletonTrackingState.PositionOnly)
                {
                    foreach (Joint joint in data.Joints)
                    {
                        if (joint.ID == JointID.HandRight || joint.ID == JointID.HandLeft)
                        {
                            Vector2 jointPosition = joint.GetScreenPosition(kinectRuntime, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
                            Rectangle rectangle = new Rectangle((int)jointPosition.X - (JointIntersectionSize / 2), (int)jointPosition.Y - (JointIntersectionSize / 2), JointIntersectionSize, JointIntersectionSize);

                            foreach (TextureInstance texture in hotSpots)
                            {
                                if (texture.CalculateBoundingRectangle().Intersects(rectangle))
                                    texture.Color = Color.LimeGreen;
                            }
                        }
                    }
                }
            }
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            kinectRGBVideo.Draw(spriteBatch);

            foreach (TextureInstance texture in hotSpots)
                texture.Draw(spriteBatch);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
