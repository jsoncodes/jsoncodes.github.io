using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace TwitterTicTacToe.Core
{
    public static class GameCore
    {
        private static Game game;
        private static Player player;

        public static void Initialize(Game thisGame)
        {
            game = thisGame;
        }

        public static Game Game
        {
            get { return game; }
        }

        public static ContentManager Content
        {
            get { return game.Content; }
        }

        public static GraphicsDevice GraphicsDevice
        {
            get { return game.GraphicsDevice; }
        }

        public static Player Player
        {
            get { return player; }
            set { player = value; }
        }
    }
}