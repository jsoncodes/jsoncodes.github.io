﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Xml.Linq;
using TwitterTicTacToe.Resources;

namespace TwitterTicTacToe.Twitter
{
    public class TwitterClient
    {
        public event EventHandler<TagSearchCompletedEventArgs> TagSearchComplete;
        public event EventHandler<EventArgs> TweetPostComplete;

        private string userAuthentication;
        private string tag;

        public TwitterClient()
        {
            userAuthentication = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(TwitterResources.AuthenticationName + ":" + TwitterResources.AuthenticationPassword));
        }

        public void SearchForTag(string tag)
        {
            if (String.IsNullOrEmpty(this.tag))
            {
                this.tag = tag;
                WebClient client = new WebClient();
                client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);
                client.DownloadStringAsync(new Uri(string.Format(TwitterResources.UserTimeline, TwitterResources.AuthenticationName)));
            }
        }

        private void client_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            try
            {
                XDocument xDoc = XDocument.Parse(e.Result);

                List<TwitterEntry> entries = new List<TwitterEntry>(from status in xDoc.Root.Elements("status")
                                                                    select new TwitterEntry(
                                                                                        (long)status.Element("id"),
                                                                                        (string)status.Element("text")
                                                                                        ));

                List<TwitterEntry> validEntries = new List<TwitterEntry>();
                string[] tags = tag.Split('&');

                for (int i = 0; i < entries.Count; i++)
                {
                    bool isValid = true;

                    for (int j = 0; j < tags.Length; j++)
                    {
                        if (!entries[i].Text.Contains(tags[j]))
                        {
                            isValid = false;
                            j = tags.Length;
                        }
                    }

                    if (isValid)
                        validEntries.Add(entries[i]);
                }

                tag = null;
                if (TagSearchComplete != null)
                    TagSearchComplete(sender, new TagSearchCompletedEventArgs(validEntries));
            }
            catch (Exception) {  }
        }

        public void PostTweet(string tweet)
        {
            try
            {
                byte[] bytes = System.Text.Encoding.ASCII.GetBytes(string.Format(TwitterResources.NewTweetParameter, tweet));

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(TwitterResources.TimeLineUpdateUrl);
                request.Method = "POST";
                request.ServicePoint.Expect100Continue = false;
                request.Headers.Add("Authorization", "Basic " + userAuthentication);
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = bytes.Length;

                using (Stream requestStream = request.GetRequestStream())
                {
                    requestStream.Write(bytes, 0, bytes.Length);
                }

                if (TweetPostComplete != null)
                    TweetPostComplete(this, EventArgs.Empty);
            }
            catch (Exception) { }
        }

        public void DeleteTweet(long tweetId)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(string.Format(TwitterResources.TweetDestroyUrl, tweetId));
                request.Method = "POST";
                request.ServicePoint.Expect100Continue = false;

                request.Headers.Add("Authorization", "Basic " + userAuthentication);
                request.ContentType = "application/x-www-form-urlencoded";
                request.BeginGetResponse(null, null);
            }
            catch (Exception) {  }
        }
    }


    public class TagSearchCompletedEventArgs : EventArgs
    {
        private List<TwitterEntry> entries;

        public TagSearchCompletedEventArgs(List<TwitterEntry> e)
        {
            entries = e;
        }

        public List<TwitterEntry> Entries
        {
            get { return entries; }
        }
    }
}
