﻿namespace TwitterTicTacToe.Twitter
{
    public class TwitterEntry
    {
        private long id;
        private string text;

        public TwitterEntry(long id, string text)
        {
            this.id = id;
            this.text = text;
        }

        public long Id
        {
            get { return id; }
        }

        public string Text
        {
            get { return text; }
        }
    }
}
