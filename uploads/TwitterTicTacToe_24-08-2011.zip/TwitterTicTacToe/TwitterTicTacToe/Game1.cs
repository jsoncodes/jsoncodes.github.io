using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using TwitterTicTacToe.Core;
using TwitterTicTacToe.Objects;
using TwitterTicTacToe.Resources;
using TwitterTicTacToe.Twitter;
using TwitterTicTacToe.Objects.Grid;
using System.Diagnostics;

namespace TwitterTicTacToe
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private const int width = 600;
        private const int height = 600;
        private const int checkWaitTime = 10000;

        private event EventHandler<EventArgs> GameNotFoundEvent;

        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private SpriteFont font;

        private GameGrid grid;
        private bool isGameReady;

        private bool findMyNewGameRequest;
        private int findMyRequestWait = 5000;
        private float findMyRequestStart = -1;

        private long gameId;
        private string waitText;
        private float lastJoinCheck;
        private float lastMoveCheck;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = width;
            graphics.PreferredBackBufferHeight = height;

            IsMouseVisible = true;

            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            GameCore.Initialize(this);

            grid = new GameGrid();
            grid.Position = new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2);
            // hook up event to listen to local player updates
            grid.GridUpdated += new EventHandler<GridCellUpdatedEventArgs>(GridUpdated);

            base.Initialize();

            SetUpGame();
        }

        #region Game setup
        private void SetUpGame()
        {
            waitText = Setup.Searching;

            GameNotFoundEvent += new EventHandler<EventArgs>(GameNotFound);

            TwitterClient searchForGame = new TwitterClient();
            searchForGame.TagSearchComplete += new EventHandler<TagSearchCompletedEventArgs>(GameSearchCompleted);
            searchForGame.SearchForTag(CommandTags.NewGameTag);
        }

        private void GameNotFound(object sender, EventArgs e)
        {
            waitText = Setup.NotFound;

            TwitterClient newGameClient = new TwitterClient();
            newGameClient.TweetPostComplete += new EventHandler<EventArgs>(NewGameRequestCreated);
            newGameClient.PostTweet(CommandTags.NewGameTag);
        }

        private void NewGameRequestCreated(object sender, EventArgs e)
        {
            waitText = Setup.NewGameRequest;

            findMyNewGameRequest = true;
        }

        private void PlayersNewGameFound(object sender, TagSearchCompletedEventArgs e)
        {
            if (e.Entries.Count > 0)
            {
                gameId = e.Entries[0].Id;
                Debug.WriteLine(gameId);
                findMyNewGameRequest = false;

                waitText = Setup.GameConfigured;
                GameCore.Player = new Player(GameResources.FirstPlayer);
                GameCore.Player.HasControl = true;
            }
            else
                waitText = Setup.Error;
        }

        private void GameSearchCompleted(object sender, TagSearchCompletedEventArgs e)
        {
            if (e.Entries.Count == 0)
                GameNotFoundEvent(this, EventArgs.Empty);
            else
            {
                waitText = Setup.GameFound;
                TwitterClient joinClient = new TwitterClient();
                gameId = e.Entries[0].Id;
                joinClient.DeleteTweet(gameId);
                joinClient.PostTweet(string.Format(CommandTags.JoinGameTag, gameId));

                isGameReady = true;
                GameCore.Player = new Player(GameResources.SecondPlayer);
            }

        }
        #endregion

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            font = Content.Load<SpriteFont>("Fonts/waiting");

            grid.LoadContent();
        }

        protected override void UnloadContent()
        {

        }

        private void GridUpdated(object sender, GridCellUpdatedEventArgs e)
        {
            string command;
            if (GameCore.Player.AssignedCharacter == GameResources.FirstPlayer)
                command = CommandTags.PlayerOneMoveTag;
            else
                command = CommandTags.PlayerTwoMoveTag;

            TwitterClient sendUpdateClient = new TwitterClient();
            sendUpdateClient.PostTweet(string.Format(command, gameId, e.CellIndex));
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            if (findMyNewGameRequest)
            {
                FindLocalPlayersNewGame(gameTime);
            }
            else
            {
                if (isGameReady)
                {
                    grid.Update(gameTime);

                    if (!GameCore.Player.HasControl)
                    {
                        ListenForOtherPlayerUpdates(gameTime);
                    }
                }
                else
                    CheckForPlayerJoining(gameTime);
            }

            base.Update(gameTime);
        }

        private void CheckForPlayerJoining(GameTime gameTime)
        {
            if (lastJoinCheck == 0 || gameTime.TotalRealTime.TotalMilliseconds - lastJoinCheck > checkWaitTime)
            {
                lastJoinCheck = (float)gameTime.TotalRealTime.TotalMilliseconds;

                TwitterClient checkForJoin = new TwitterClient();
                checkForJoin.TagSearchComplete += new EventHandler<TagSearchCompletedEventArgs>(JoinGameSearchComplete);
                checkForJoin.SearchForTag(string.Format(CommandTags.JoinGameTag, gameId));
            }
        }

        private void ListenForOtherPlayerUpdates(GameTime gameTime)
        {
            if (lastMoveCheck == 0 || gameTime.TotalRealTime.TotalMilliseconds - lastMoveCheck > checkWaitTime)
            {
                Debug.WriteLine("Checking for updates");

                lastMoveCheck = (float)gameTime.TotalRealTime.TotalMilliseconds;

                string updateTags;
                if (GameCore.Player.AssignedCharacter == GameResources.FirstPlayer)
                    updateTags = CommandTags.PlayerTwoMoveSearch;
                else
                    updateTags = CommandTags.PlayerOneMoveSearch;

                TwitterClient checkForUpdate = new TwitterClient();
                checkForUpdate.TagSearchComplete += new EventHandler<TagSearchCompletedEventArgs>(CheckForMovesComplete);
                checkForUpdate.SearchForTag(string.Format(updateTags, gameId));
            }
        }

        private void FindLocalPlayersNewGame(GameTime gameTime)
        {
            if (findMyRequestStart < 0)
                findMyRequestStart = (float)gameTime.TotalRealTime.TotalMilliseconds;
            else if (gameTime.TotalRealTime.TotalMilliseconds - findMyRequestStart > findMyRequestWait)
            {
                findMyRequestStart = (float)gameTime.TotalRealTime.TotalMilliseconds;

                TwitterClient newGameClient = new TwitterClient();
                newGameClient.TagSearchComplete += new EventHandler<TagSearchCompletedEventArgs>(PlayersNewGameFound);
                newGameClient.SearchForTag(CommandTags.NewGameTag);
            }
        }

        private void CheckForMovesComplete(object sender, TagSearchCompletedEventArgs e)
        {
            Debug.WriteLine("Checking for updates complete");
            if (e.Entries.Count > 0)
            {
                Debug.WriteLine("Checking for updates complete - valid move");

                string[] parts = e.Entries[0].Text.Split(' ');
                int cellIndex = Int32.Parse(parts[parts.Length - 1]);

                string character;
                if (GameCore.Player.AssignedCharacter == GameResources.FirstPlayer)
                    character = GameResources.SecondPlayer;
                else
                    character = GameResources.FirstPlayer;

                grid.UpdateCell(cellIndex, character);

                TwitterClient deleteMoveTweet = new TwitterClient();
                deleteMoveTweet.DeleteTweet(e.Entries[0].Id);
            }
        }

        private void JoinGameSearchComplete(object sender, TagSearchCompletedEventArgs e)
        {
            if (e.Entries.Count > 0)
            {
                isGameReady = true;
                TwitterClient joinClient = new TwitterClient();
                joinClient.TagSearchComplete += new EventHandler<TagSearchCompletedEventArgs>(joinClient_TagSearchComplete);
                joinClient.SearchForTag(string.Format(CommandTags.JoinGameTag, gameId));
            }
        }

        private void joinClient_TagSearchComplete(object sender, TagSearchCompletedEventArgs e)
        {
            if (e.Entries.Count > 0)
            {
                TwitterClient deleteJoin = new TwitterClient();
                deleteJoin.DeleteTweet(e.Entries[0].Id);
            }
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            spriteBatch.Begin(SpriteBlendMode.AlphaBlend);

            if (isGameReady)
                grid.Draw(spriteBatch);
            else
                spriteBatch.DrawString(font, waitText, Vector2.Zero, Color.White);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
