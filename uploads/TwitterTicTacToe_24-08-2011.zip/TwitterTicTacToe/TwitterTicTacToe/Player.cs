﻿namespace TwitterTicTacToe
{
    public class Player
    {
        private string assignedChar;
        private bool hasControl;

        public Player(string character)
        {
            assignedChar = character;
        }

        public string AssignedCharacter
        {
            get { return assignedChar; }
        }

        public bool HasControl
        {
            get { return hasControl; }
            set { hasControl = value; }
        }
    }
}
