using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TwitterTicTacToe.Objects
{
    public enum GameObjectStatus
    {
        Dead,     // Dead objects should be removed from memory
        Inactive, // Disabled and hidden
        Hidden,   // Enabled and hidden
        Active    // Enabled and visible
    }
}