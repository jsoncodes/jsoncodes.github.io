using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace TwitterTicTacToe.Objects
{
    public class GameObject
    {
        private Vector2 position;
        private Vector2 velocity;
        private Vector2 origin;
        private float friction = 1;

        private float width;
        private float height;
        private float radius;
        private float scale = 1f;

        private GameObjectStatus status = GameObjectStatus.Active;

        public virtual void Update(GameTime gameTime)
        {
            if (status != GameObjectStatus.Dead && status != GameObjectStatus.Inactive)
            {
                position += velocity;
                velocity *= 1 - friction;
            }
        }

        protected Rectangle CalculateBoundingBox(Vector2 boxPosition)
        {
            return new Rectangle((int)(boxPosition.X - (scale * origin.X)), (int)(boxPosition.Y - (scale * origin.Y)), (int)width, (int)height);
        }

        #region Properties

        public Vector2 Position
        {
            get { return position; }
            set { position = value; }
        }

        public Vector2 Velocity
        {
            get { return velocity; }
            set { velocity = value; }
        }

        public Vector2 ProjectedPosition
        {
            get { return position + velocity; }
        }

        public Vector2 Origin
        {
            get { return origin; }
            set { origin = value; }
        }

        public float Friction
        {
            get { return friction; }
            set { friction = value; }
        }

        public float Width
        {
            get { return width; }
            set { width = value; }
        }

        public float Height
        {
            get { return height; }
            set { height = value; }
        }

        public float Radius
        {
            get { return radius; }
            set { radius = value; }
        }

        public float Scale
        {
            get { return scale; }
            set
            {
                scale = value;
                width *= scale;
                height *= scale;
            }
        }

        public Rectangle BoundingBox
        {
            get { return CalculateBoundingBox(Position); }
        }

        public Rectangle ProjectedBoundingBox
        {
            get { return CalculateBoundingBox(ProjectedPosition); }
        }

        public GameObjectStatus Status
        {
            get { return status; }
            set { status = value; }
        }

        #endregion
    }
}