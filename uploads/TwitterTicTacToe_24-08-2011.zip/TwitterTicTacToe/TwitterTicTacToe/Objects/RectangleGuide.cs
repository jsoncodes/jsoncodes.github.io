using Microsoft.Xna.Framework.Graphics;

namespace TwitterTicTacToe.Objects
{
    public class RectangleGuide : Sprite
    {
        private const string texturePath = "Textures/guide";

        public RectangleGuide()
        {
            Color color = Color;
            color.A = 125;
            Color = color;
        }

        public virtual void LoadContent()
        {
            LoadContent(texturePath);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            if(Status == GameObjectStatus.Active)
                spriteBatch.Draw(Texture, BoundingBox, Color);
        }
    }
}