﻿using Microsoft.Xna.Framework.Graphics;
using TwitterTicTacToe.Objects.Grid;
using Microsoft.Xna.Framework;
using System;
using TwitterTicTacToe.Core;

namespace TwitterTicTacToe.Objects
{
    public class GameGrid : Sprite
    {
        private const string texturePath = "Textures/grid";

        public event EventHandler<GridCellUpdatedEventArgs> GridUpdated;
        private GridCell[] cells = new GridCell[9];

        public GameGrid()
        {
            CreateGridCells();
        }

        private void CreateGridCells()
        {
            for (int i = 0; i < cells.Length; i++)
            {
                cells[i] = new GridCell(i);
                cells[i].GridCellUpdated += new EventHandler<GridCellUpdatedEventArgs>(GameGrid_GridCellUpdated);
            }
        }

        private void GameGrid_GridCellUpdated(object sender, GridCellUpdatedEventArgs e)
        {
            if (GridUpdated != null)
                GridUpdated(this, e);
        }

        public void LoadContent()
        {
            LoadContent(texturePath);

            LoadGridCells();
        }

        private void LoadGridCells()
        {
            float cellWidth = Texture.Width / 3;
            float cellHeight = Texture.Height / 3;

            Rectangle gridBounding = BoundingBox;

            for (int i = 0; i < cells.Length; i++)
            {
                cells[i].LoadContent();

                cells[i].Width = cellWidth;
                cells[i].Height = cellHeight;
                cells[i].Origin = new Vector2(cellWidth / 2, cellHeight / 2);

                cells[i].Position = CalculateCellPosition(i, gridBounding);
            }
        }

        private Vector2 CalculateCellPosition(int index, Rectangle gridBounding)
        {
            float cellWidth = Texture.Width / 3;
            float cellHeight = Texture.Height / 3;

            Vector2 position = new Vector2(gridBounding.X + (cellWidth / 2), gridBounding.Y + (cellHeight / 2));

            if (index == 1 || index == 4 || index == 7)
                position.X += cellWidth;
            else if (index == 2 || index == 5 || index == 8)
                position.X += cellWidth * 2;

            if (index >= 3 && index <= 5)
                position.Y += cellHeight;
            else if (index >= 6 && index <= 8)
                position.Y += cellHeight * 2;

            return position;
        }

        public override void Update(GameTime gameTime)
        {
            for (int i = 0; i < cells.Length; i++)
            {
                cells[i].Update();
            }
        }

        public void UpdateCell(int index, string character)
        {
            cells[index].Character = character;
            GameCore.Player.HasControl = true;
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);

            DrawGridCells(spriteBatch);
        }

        private void DrawGridCells(SpriteBatch spriteBatch)
        {
            for (int i = 0; i < cells.Length; i++)
            {
                cells[i].Draw(spriteBatch);
            }
        }
    }
}
