﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using TwitterTicTacToe.Core;
using System;

namespace TwitterTicTacToe.Objects.Grid
{
    public class GridCell : RectangleGuide
    {
        public event EventHandler<GridCellUpdatedEventArgs> GridCellUpdated;
        private const string fontPath = "Fonts/char";

        private int index;
        private string charContained;
        private Vector2 charOrigin;
        private SpriteFont font;

        public GridCell(int index)
        {
            this.index = index;
            GridCellUpdated += new EventHandler<GridCellUpdatedEventArgs>(GridCell_GridCellUpdated);
        }

        public override void LoadContent()
        {
            font = GameCore.Content.Load<SpriteFont>(fontPath);
            base.LoadContent();
        }

        public void Update()
        {
            MouseState state = Mouse.GetState();
            Point mousePosition = new Point(state.X, state.Y);

            if (GameCore.Player.HasControl && BoundingBox.Contains(mousePosition))
            {
                if (!string.IsNullOrEmpty(charContained))
                    Color = new Color(255, 0, 0, 125);
                else
                    Color = new Color(0, 255, 0, 125);

                if (state.LeftButton == ButtonState.Pressed && string.IsNullOrEmpty(charContained))
                {
                    if (GridCellUpdated != null)
                        GridCellUpdated(this, new GridCellUpdatedEventArgs(index));
                }
            }
            else
                Color = new Color(0, 0, 0, 0);
        }

        private void GridCell_GridCellUpdated(object sender, GridCellUpdatedEventArgs e)
        {
            charContained = GameCore.Player.AssignedCharacter;
            Vector2 charSize = font.MeasureString(charContained.ToString());
            charOrigin = new Vector2(charSize.X / 2, charSize.Y / 2);

            GameCore.Player.HasControl = false;
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
            if (!string.IsNullOrEmpty(charContained))
                spriteBatch.DrawString(font, charContained.ToString(), Position, Color.White, 0f, charOrigin, 1f, SpriteEffects.None, 0f);

        }

        public string Character
        {
            get { return charContained; }
            set
            { 
                charContained = value;
                Vector2 charSize = font.MeasureString(charContained.ToString());
                charOrigin = new Vector2(charSize.X / 2, charSize.Y / 2);
            }
        }
    }

    public class GridCellUpdatedEventArgs : EventArgs
    {
        private int cellIndex;

        public GridCellUpdatedEventArgs(int index)
        {
            cellIndex = index;
        }

        public int CellIndex
        {
            get { return cellIndex; }
        }
    }
}
