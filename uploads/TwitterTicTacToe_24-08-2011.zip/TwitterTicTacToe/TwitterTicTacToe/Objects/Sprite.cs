using TwitterTicTacToe.Core;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace TwitterTicTacToe.Objects
{
    public class Sprite : GameObject
    {
        private Texture2D texture;
        private Color color = Color.White;
        private SpriteEffects effects = SpriteEffects.None;

        private float rotation;

        public void LoadContent(string textureToLoad)
        {
            texture = GameCore.Content.Load<Texture2D>(textureToLoad);

            if (Width == 0 || Height == 0)
            {
                Width = texture.Width;
                Height = texture.Height;
            }

            Origin = new Vector2(Width / 2, Height / 2);

            SetSpriteRadius();
        }

        private void SetSpriteRadius()
        {
            if (Height > Width)
                Radius = Height / 2;
            else
                Radius = Width / 2;
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            if(Status == GameObjectStatus.Active)
                spriteBatch.Draw(texture, Position, null, color, rotation, Origin, Scale, effects, 0);
        }

        #region Properties

        public Texture2D Texture
        {
            get { return texture; }
        }

        public Color Color
        {
            get { return color; }
            set { color = value; }
        }

        public float Rotation
        {
            get { return rotation; }
            set { rotation = value; }
        }

        #endregion
    }
}